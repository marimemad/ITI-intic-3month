(function(){
    console.log('msg')
}())